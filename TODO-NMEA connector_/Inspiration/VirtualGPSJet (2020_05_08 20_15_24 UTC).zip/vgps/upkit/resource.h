//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by upkit.rc
//
#define IDR_MAINFRAME                   128
#define IDD_MAINDLG                     129
#define IDD_MAINTAB                     130
#define IDD_POSTAB                      131
#define IDD_SIGNALTAB                   132
#define IDACTIVATE                      1000
#define IDACTIVATE2                     1001
#define IDDEACTIVATE                    1001
#define IDC_TAB                         1001
#define IDC_DRV_COMBO                   1002
#define IDC_EDIT1                       1003
#define IDC_EDIT2                       1004
#define IDC_BUTTON1                     1005
#define IDC_BUTTON2                     1006
#define IDC_COMBO1                      1007
#define IDC_COMBO2                      1008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
